# Loan Approval Web App

A simple machine learning-powered web app to predict whether a user qualifies for a loan.

## 🔧 Setup Instructions

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Train the model
```bash
python train_model.py
```

### 3. Run the Flask server
```bash
python app.py
```

### 4. Use the app
Open a browser and go to `http://127.0.0.1:5000`

---
